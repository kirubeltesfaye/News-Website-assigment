<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiralanos";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // prepare sql and bind parameters
    $stmt = $conn->prepare("INSERT INTO title (Title, content)
    VALUES (:Title, :content)");
    $stmt->bindParam(':Title', $Title);
    $stmt->bindParam(':content', $content);


        $Title=$_POST['Title'];
        $content=$_POST['content'];
        $stmt->execute();
    echo "New records created successfully";
    }
catch(PDOException $e)
    {
    echo "Error: " . $e->getMessage();
    }
$conn = null;
?>
