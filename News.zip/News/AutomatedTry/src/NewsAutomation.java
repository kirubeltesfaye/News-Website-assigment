import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewsAutomation {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://www.ethiopianreporter.com/zena");
        WebElement title = driver.findElement(By.xpath("//*[@id='block-gavias-kama-content']/div/div/div/div/div[1]/article/div/div[2]/h3/a"));
        WebElement body = driver.findElement(By.xpath("//*[@id='block-gavias-kama-content']/div/div/div/div/div[1]/article/div/div[2]/div[2]/div"));
        title.getText();
        System.out.println(title.getText());
        System.out.println(body.getText());


        WebDriver newsdriver = new ChromeDriver();
        newsdriver.navigate().to("http://localhost/kiralanos/hompage.html");
        newsdriver.findElement(By.id("Title")).sendKeys(title.getText());
        newsdriver.findElement(By.id("content")).sendKeys(body.getText());
        newsdriver.findElement(By.name("submit")).click();

        driver.navigate().to("http://www.awrambatimes.com/");
        WebElement title2 = driver.findElement(By.xpath("//*[@id='post-17045']/div/h2/a"));
        WebElement body2 = driver.findElement(By.xpath("//*[@id='post-17045']/div/div[3]"));
        System.out.println(title2.getText());
        System.out.println(body2.getText());
        newsdriver.navigate().back();
        newsdriver.navigate().refresh();
        newsdriver.findElement(By.name("Title")).sendKeys(title2.getText());
        newsdriver.findElement(By.name("content")).sendKeys(body2.getText());
        newsdriver.findElement(By.name("submit")).click();




        driver.navigate().to("https://www.bbc.com/amharic");
        WebElement title3 = driver.findElement(By.cssSelector(".buzzard-item > a:nth-child(1) > h3:nth-child(1) > span:nth-child(1)"));
        System.out.println(title3.getText());
        WebElement body3 = driver.findElement(By.cssSelector(".buzzard__body"));
        System.out.println(body3.getText());
        newsdriver.navigate().back();
        newsdriver.navigate().refresh();
        newsdriver.findElement(By.name("Title")).sendKeys(title3.getText());
        newsdriver.findElement(By.name("content")).sendKeys(body3.getText());
        newsdriver.findElement(By.name("submit")).click();
        newsdriver.navigate().back();
        newsdriver.navigate().refresh();
        newsdriver.findElement(By.id("displayNews")).click();


        try {
            Thread.sleep(10000);
        }catch (Exception E){

        }
        driver.close();
        //newsdriver.close();
    }
}